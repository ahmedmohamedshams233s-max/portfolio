"""Shared evaluation metrics: BLEU-1..4, ROUGE-L (own LCS implementation) and clinical-efficacy (CE) F1."""
import numpy as np
from nltk.translate.bleu_score import SmoothingFunction, corpus_bleu
from sklearn.metrics import precision_recall_fscore_support

from src.datasets.labeler import K, LABELS, label_vec

SM = SmoothingFunction().method1


def lcs(a, b):
    if not a or not b:
        return 0
    prev = [0] * (len(b) + 1)
    for x in a:
        cur = [0]
        for j, y in enumerate(b):
            cur.append(prev[j] + 1 if x == y else max(prev[j + 1], cur[j]))
        prev = cur
    return prev[-1]


def rouge_l(ref, hyp):
    r, h = ref.split(), hyp.split()
    l = lcs(r, h)
    if l == 0:
        return 0.0
    p, rc = l / len(h), l / len(r)
    return 2 * p * rc / (p + rc)


def bleu_all(refs, hyps):
    if all(len(h.split()) == 0 for h in hyps):
        return [0.0] * 4
    R, H = [[r.split()] for r in refs], [h.split() for h in hyps]
    return [float(corpus_bleu(R, H, weights=w, smoothing_function=SM))
            for w in [(1, 0, 0, 0), (.5, .5, 0, 0), (1/3, 1/3, 1/3, 0), (.25, .25, .25, .25)]]


def compute_metrics(refs, hyps):
    b = bleu_all(refs, hyps)
    rl = float(np.mean([rouge_l(r, h) for r, h in zip(refs, hyps)]))
    Y = np.stack([label_vec(t) for t in refs]); P = np.stack([label_vec(t) for t in hyps])
    p, r, f, _ = precision_recall_fscore_support(Y, P, average=None, zero_division=0)
    micro = float(precision_recall_fscore_support(Y, P, average="micro", zero_division=0)[2])
    sup = Y.sum(0)
    macro = float(f[sup > 0].mean())
    return dict(bleu1=b[0], bleu2=b[1], bleu3=b[2], bleu4=b[3], rougeL=rl, ce_micro_f1=micro, ce_macro_f1=macro,
                composite=float(np.mean([b[3], rl, micro])), avg_len=float(np.mean([len(h.split()) for h in hyps])),
                per_class={LABELS[k]: dict(p=float(p[k]), r=float(r[k]), f1=float(f[k]), support=int(sup[k])) for k in range(K)})


def boot_ci(refs, hyps, n=200, seed=0):
    """Bootstrap 95% CI (BLEU-4, ROUGE-L) by resampling test reports."""
    rg = np.random.RandomState(seed); N = len(refs)
    rls = np.array([rouge_l(r, h) for r, h in zip(refs, hyps)]); b4, rl = [], []
    for _ in range(n):
        ix = rg.randint(0, N, N)
        b4.append(bleu_all([refs[i] for i in ix], [hyps[i] for i in ix])[3]); rl.append(rls[ix].mean())
    f = lambda a: f"[{np.percentile(a, 2.5):.3f}, {np.percentile(a, 97.5):.3f}]"
    return f(b4), f(rl)
