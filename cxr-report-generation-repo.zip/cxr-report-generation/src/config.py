"""Global configuration, experiment specs and small helpers (shared by every script)."""
import os
import random
from pathlib import Path

import numpy as np
import torch

ROOT = Path(os.environ.get("CXR_ROOT", Path(__file__).resolve().parents[1]))
DATA_DIR = Path(os.environ.get("CXR_DATA", ROOT / "data" / "raw"))      # raw data: never committed to git
PROC_DIR = ROOT / "data" / "processed"
RES = Path(os.environ.get("CXR_RESULTS", ROOT / "experiments"))         # logs, result tables, figures
CKPT = Path(os.environ.get("CXR_CKPT", ROOT / "checkpoints"))
for _p in (DATA_DIR, PROC_DIR, RES, CKPT):
    _p.mkdir(parents=True, exist_ok=True)

SMOKE = os.environ.get("CXR_SMOKE", "0") == "1"    # tiny run to test the pipeline
FORCE = os.environ.get("CXR_FORCE", "0") == "1"    # ignore cached results

CFG = dict(SPLIT_SEED=42, IMG=224, MAX_LEN=60, MIN_FREQ=3, BATCH=32,
           EPOCHS=12, TUNE_EPOCHS=6, PATIENCE=4, SEEDS=[0, 1, 2],
           LR_GRID=[1e-4, 3e-4, 1e-3], D_MODEL=256, N_LAYERS=3, N_HEADS=8,
           WD=0.01, LABEL_SMOOTH=0.1, AUX_W=0.5, NO_REPEAT_N=4)
if SMOKE:
    CFG.update(EPOCHS=1, TUNE_EPOCHS=1, LR_GRID=[3e-4])

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
HW = torch.cuda.get_device_name(0) if DEVICE == "cuda" else "CPU"

# One entry per model / experiment. "name" is used for result files and checkpoints.
SPECS = {
    "M1":         dict(kind="cnn_lstm", pretrained=True,  augment=True),
    "M2":         dict(kind="vit_tf",   pretrained=True,  augment=True),
    "M3":         dict(kind="vit_tf",   pretrained=True,  augment=True, multiview=True, use_tags=True),
    # studies / ablations
    "M2_noaug":   dict(kind="vit_tf",   pretrained=True,  augment=False),
    "M1_scratch": dict(kind="cnn_lstm", pretrained=False, augment=True),
    "M2_scratch": dict(kind="vit_tf",   pretrained=False, augment=True),
    "M3_nolat":   dict(kind="vit_tf",   pretrained=True,  augment=True, multiview=False, use_tags=True),
    "M3_notags":  dict(kind="vit_tf",   pretrained=True,  augment=True, multiview=True,  use_tags=False),
}
# which tuned LR each experiment inherits
LR_PARENT = {"M1": "M1", "M2": "M2", "M3": "M3", "M2_noaug": "M2", "M1_scratch": "M1",
             "M2_scratch": "M2", "M3_nolat": "M3", "M3_notags": "M3"}
NICE = {"M1": "M1 CNN-LSTM (classic)", "M2": "M2 ViT-Transformer (modern)", "M3": "M3 Multi-view Tag-guided (advanced)"}


def set_seed(s: int):
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)


def best_lr_path() -> Path:
    return RES / "best_lr.json"
