"""Training engine used by EVERY experiment (same data, preprocessing, optimizer, decoding -> fair comparison).

Usage examples (from the repo root):
    python -m src.train --name M2 --seed 0 --lr 3e-4 --epochs 12 --splits val test --stage final --ckpt
    python -m src.train --name M1 --seed 0 --lr 1e-3 --epochs 6 --splits val --stage tune
"""
import argparse
import gc
import json
import math
import time

import torch
import torch.nn as nn

from src.config import CFG, CKPT, DEVICE, FORCE, HW, RES, SPECS, set_seed
from src.datasets.cxr import load_data, make_loader, prep
from src.metrics import compute_metrics
from src.models import build_model

MAX_LEN = CFG["MAX_LEN"]
AC = lambda: torch.autocast(device_type=DEVICE, dtype=torch.float16, enabled=(DEVICE == "cuda"))


@torch.no_grad()
def eval_loss(model, loader):
    model.eval(); tot = n = 0
    for batch in loader:
        b = prep(batch)
        with AC():
            l, _ = model.loss(b)
        tot += l.item() * len(b["idx"]); n += len(b["idx"])
    return tot / n


@torch.no_grad()
def generate_all(model, loader, tok):
    model.eval(); hyps = []
    if DEVICE == "cuda":
        torch.cuda.synchronize()
    t0 = time.time()
    for batch in loader:
        b = prep(batch)
        with AC():
            ids = model.generate(b, MAX_LEN + 1)
        hyps += [tok.decode(s) for s in ids.cpu()]
    if DEVICE == "cuda":
        torch.cuda.synchronize()
    return hyps, time.time() - t0


def run_exp(data, name, spec, seed, lr, epochs, splits=("val",), stage="final", save_ckpt=False):
    if stage == "tune":
        assert tuple(splits) == ("val",), "the test set must NOT be used while tuning"
    fn = RES / f"run__{name}__s{seed}__lr{lr:g}__e{epochs}.json"
    if fn.exists() and not FORCE:
        return json.load(open(fn))
    set_seed(seed)
    tl = make_loader(data.DS["train_aug" if spec["augment"] else "train"], True, seed)
    vl = make_loader(data.DS["val"], False)
    model = build_model(spec, data.V).to(DEVICE)
    params = sum(p.numel() for p in model.parameters())
    enc_ids = {id(p) for p in model.encoder_params()}
    enc = [p for p in model.parameters() if id(p) in enc_ids]
    rest = [p for p in model.parameters() if id(p) not in enc_ids]
    opt = torch.optim.AdamW([{"params": enc, "lr": lr * 0.3 if spec["pretrained"] else lr}, {"params": rest, "lr": lr}],
                            weight_decay=CFG["WD"])
    total = epochs * len(tl); warm = max(1, int(0.05 * total))
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: (s + 1) / warm if s < warm else 0.5 * (1 + math.cos(math.pi * (s - warm) / max(1, total - warm))))
    scaler = torch.amp.GradScaler("cuda", enabled=(DEVICE == "cuda"))
    if DEVICE == "cuda":
        torch.cuda.reset_peak_memory_stats()
    best, best_state, bad, hist, t_train = 1e9, None, 0, [], 0.0
    for ep in range(epochs):
        model.train(); t0 = time.time(); run = cnt = 0
        for batch in tl:
            b = prep(batch); opt.zero_grad(set_to_none=True)
            with AC():
                loss, _ = model.loss(b)
            scaler.scale(loss).backward(); scaler.unscale_(opt)
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(opt); scaler.update(); sched.step()
            run += loss.item() * len(b["idx"]); cnt += len(b["idx"])
        if DEVICE == "cuda":
            torch.cuda.synchronize()
        t_train += time.time() - t0
        vloss = eval_loss(model, vl)
        hist.append(dict(epoch=ep + 1, train_loss=run / cnt, val_loss=vloss))
        print(f"  [{name} s{seed} lr{lr:g}] ep {ep+1}/{epochs} train {run/cnt:.3f} val {vloss:.3f} ({time.time()-t0:.0f}s)")
        if vloss < best - 1e-4:
            best, bad = vloss, 0
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            bad += 1
            if bad >= CFG["PATIENCE"]:
                print("  early stop"); break
    peak = torch.cuda.max_memory_allocated() / 2**20 if DEVICE == "cuda" else 0.0
    model.load_state_dict(best_state)
    res = dict(name=name, spec=spec, seed=seed, lr=lr, epochs=epochs, epochs_run=len(hist), stage=stage, history=hist,
               best_val_loss=best, train_time_s=t_train, params=params, peak_mem_mb=peak, hardware=HW, file=str(fn), preds={})
    for sp in splits:
        hyps, dt = generate_all(model, make_loader(data.DS[sp], False), data.tok)
        res[f"metrics_{sp}"] = compute_metrics(data.REFS[sp], hyps)
        res[f"infer_ms_{sp}"] = 1000 * dt / len(hyps)
        pf = RES / f"pred__{name}__s{seed}__lr{lr:g}__e{epochs}__{sp}.json"
        json.dump(hyps, open(pf, "w")); res["preds"][sp] = str(pf)
    if save_ckpt:
        ck = CKPT / f"{name}__s{seed}.pt"
        torch.save(best_state, ck); res["ckpt"] = str(ck); res["ckpt_mb"] = ck.stat().st_size / 2**20
        json.dump(data.tok.itos, open(CKPT / "vocab.json", "w"))          # needed by the demo
    json.dump(res, open(fn, "w"))
    del model, opt; gc.collect(); torch.cuda.empty_cache()
    r = res.get("metrics_test", res["metrics_val"])
    print(f"  -> done: composite {r['composite']:.3f} | bleu4 {r['bleu4']:.3f} | rougeL {r['rougeL']:.3f} | CE-F1 {r['ce_micro_f1']:.3f}")
    return res


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True, choices=list(SPECS)); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--lr", type=float, default=3e-4); ap.add_argument("--epochs", type=int, default=CFG["EPOCHS"])
    ap.add_argument("--splits", nargs="+", default=["val"]); ap.add_argument("--stage", default="final", choices=["tune", "final", "study"])
    ap.add_argument("--ckpt", action="store_true")
    a = ap.parse_args()
    run_exp(load_data(), a.name, SPECS[a.name], a.seed, a.lr, a.epochs, tuple(a.splits), a.stage, a.ckpt)
