"""Run the whole experimental protocol: tuning -> final 3-seed runs -> studies/ablations.

Usage:  python -m src.run_all            (set CXR_SMOKE=1 for a quick pipeline test)
Finished runs are cached as JSON in experiments/, so you can re-run after a disconnect and it resumes.
"""
import json

from src.config import CFG, LR_PARENT, SPECS, best_lr_path
from src.datasets.cxr import load_data
from src.train import run_exp


def main():
    data = load_data()
    # ---- 1) hyper-parameter study: same budget for every model, validation set only ----
    scores = {}
    for k in ["M1", "M2", "M3"]:
        for lr in CFG["LR_GRID"]:
            r = run_exp(data, k, SPECS[k], 0, lr, CFG["TUNE_EPOCHS"], ("val",), stage="tune")
            scores[(k, lr)] = r["metrics_val"]["composite"]
    best = {k: max(CFG["LR_GRID"], key=lambda lr: scores[(k, lr)]) for k in ["M1", "M2", "M3"]}
    json.dump(best, open(best_lr_path(), "w")); print("best LR:", best)
    # ---- 2) final runs (3 seeds) ----
    for k in ["M1", "M2", "M3"]:
        for s in CFG["SEEDS"]:
            run_exp(data, k, SPECS[k], s, best[k], CFG["EPOCHS"], ("val", "test"), "final", save_ckpt=(s == 0))
    # ---- 3) data-strategy, pretrained-vs-scratch, ablations ----
    for k in ["M2_noaug", "M1_scratch", "M2_scratch", "M3_nolat", "M3_notags"]:
        for s in CFG["SEEDS"]:
            run_exp(data, k, SPECS[k], s, best[LR_PARENT[k]], CFG["EPOCHS"], ("val", "test"), "study")
    print("all runs done -> now: python -m src.evaluate tables")


if __name__ == "__main__":
    main()
