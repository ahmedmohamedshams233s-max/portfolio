from src.models.cnn_lstm import CNNLSTM
from src.models.vit_transformer import ReportTransformer


def build_model(spec, V):
    """Build a model from an experiment spec (see src/config.py: SPECS)."""
    if spec["kind"] == "cnn_lstm":
        return CNNLSTM(V, pretrained=spec["pretrained"])
    return ReportTransformer(V, pretrained=spec["pretrained"], multiview=spec.get("multiview", False),
                             use_tags=spec.get("use_tags", False))
