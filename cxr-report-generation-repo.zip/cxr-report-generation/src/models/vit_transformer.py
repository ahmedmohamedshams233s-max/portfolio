"""M2 (modern) and M3 (advanced): ViT-S/16 encoder + our own Transformer decoder.

M2 = frontal view only.
M3 = frontal + lateral views (view embeddings, masked when the lateral view is missing)
     + auxiliary disease-tag head whose probabilities become 'tag tokens' the decoder cross-attends to.
"""
import timm
import torch
import torch.nn as nn
import torch.nn.functional as F

from src.config import CFG
from src.datasets.labeler import K
from src.models.common import TDecoder, greedy_decode, lm_loss


class ReportTransformer(nn.Module):
    def __init__(self, V, pretrained=True, multiview=False, use_tags=False, K=K,
                 d=CFG["D_MODEL"], L=CFG["N_LAYERS"], h=CFG["N_HEADS"], drop=0.1):
        super().__init__()
        self.multiview, self.use_tags = multiview, use_tags
        self.vit = timm.create_model("vit_small_patch16_224", pretrained=pretrained, num_classes=0)
        D = self.vit.num_features
        self.proj = nn.Sequential(nn.Linear(D, d), nn.LayerNorm(d))
        self.view_emb = nn.Parameter(torch.randn(2, 1, d) * 0.02)
        if use_tags:
            self.tag_head = nn.Linear(D, K)                           # auxiliary multi-label classifier
            self.tag_emb = nn.Parameter(torch.randn(K, 2, d))         # per-tag embeddings: [present, absent]
        self.dec = TDecoder(V, d, h, L, drop)

    def encoder_params(self):
        return self.vit.parameters()

    def memory(self, b):
        """Returns (memory tokens, memory mask, tag logits or None)."""
        zf = self.vit.forward_features(b["f"])
        mem = [self.proj(zf) + self.view_emb[0]]
        mask = [torch.ones(mem[0].shape[:2], dtype=torch.bool, device=zf.device)]
        pooled = zf.mean(1)
        if self.multiview:
            zl = self.vit.forward_features(b["l"])
            ml = self.proj(zl) + self.view_emb[1]
            hasl = b["has_l"] > 0.5
            mem.append(ml); mask.append(hasl[:, None].expand(-1, ml.size(1)))
            w = hasl.float()[:, None]
            pooled = (zf.mean(1) + zl.mean(1) * w) / (1 + w)
        logits = None
        if self.use_tags:
            logits = self.tag_head(pooled)
            p = torch.sigmoid(logits.float())[..., None]
            tt = p * self.tag_emb[:, 0] + (1 - p) * self.tag_emb[:, 1]      # (B, K, d) tag tokens
            mem.append(tt.to(mem[0].dtype))
            mask.append(torch.ones(tt.shape[:2], dtype=torch.bool, device=tt.device))
        return torch.cat(mem, 1), torch.cat(mask, 1), logits

    def loss(self, b):
        mem, mask, logits = self.memory(b); T = b["tokens"]
        l = lm_loss(self.dec(T[:, :-1], mem, mask), T[:, 1:])
        info = {"lm": l.item()}
        if logits is not None:
            aux = F.binary_cross_entropy_with_logits(logits.float(), b["labels"])
            l = l + CFG["AUX_W"] * aux
            info["aux"] = aux.item()
        return l, info

    @torch.no_grad()
    def generate(self, b, max_len):
        mem, mask, _ = self.memory(b)
        return greedy_decode(lambda ys: self.dec(ys, mem, mask)[:, -1], mem.size(0), max_len)
