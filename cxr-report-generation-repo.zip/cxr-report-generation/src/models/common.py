"""Components written from scratch: multi-head attention, Transformer decoder, loss and greedy decoding."""
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.config import CFG, DEVICE


class MHA(nn.Module):
    """Multi-head scaled dot-product attention with optional causal and key-padding masks."""

    def __init__(self, d, h, drop=0.1):
        super().__init__()
        self.h, self.drop = h, drop
        self.q, self.k, self.v, self.o = (nn.Linear(d, d) for _ in range(4))

    def forward(self, x, kv, causal=False, kv_mask=None):
        B, Lq, _ = x.shape
        Lk = kv.size(1)
        q = self.q(x).view(B, Lq, self.h, -1).transpose(1, 2)
        k = self.k(kv).view(B, Lk, self.h, -1).transpose(1, 2)
        v = self.v(kv).view(B, Lk, self.h, -1).transpose(1, 2)
        att = (q @ k.transpose(-2, -1)) / math.sqrt(q.size(-1))
        if causal:
            att = att.masked_fill(torch.triu(torch.ones(Lq, Lk, dtype=torch.bool, device=x.device), 1), float("-inf"))
        if kv_mask is not None:
            att = att.masked_fill(~kv_mask[:, None, None, :], float("-inf"))
        att = F.dropout(att.softmax(-1), self.drop, self.training)
        return self.o((att @ v).transpose(1, 2).reshape(B, Lq, -1))


class DecLayer(nn.Module):
    def __init__(self, d, h, ff, drop):
        super().__init__()
        self.n1, self.n2, self.n3 = nn.LayerNorm(d), nn.LayerNorm(d), nn.LayerNorm(d)
        self.sa, self.ca = MHA(d, h, drop), MHA(d, h, drop)
        self.ff = nn.Sequential(nn.Linear(d, ff), nn.GELU(), nn.Dropout(drop), nn.Linear(ff, d))
        self.dr = nn.Dropout(drop)

    def forward(self, x, mem, mm):
        h = self.n1(x)
        x = x + self.dr(self.sa(h, h, causal=True))                 # masked self-attention
        x = x + self.dr(self.ca(self.n2(x), mem, kv_mask=mm))       # cross-attention to image tokens
        return x + self.dr(self.ff(self.n3(x)))


class TDecoder(nn.Module):
    def __init__(self, V, d, h, L, drop=0.1, maxpos=128):
        super().__init__()
        self.d = d
        self.emb, self.pos = nn.Embedding(V, d, padding_idx=0), nn.Embedding(maxpos, d)
        self.layers = nn.ModuleList([DecLayer(d, h, 4 * d, drop) for _ in range(L)])
        self.ln, self.out, self.dr = nn.LayerNorm(d), nn.Linear(d, V), nn.Dropout(drop)

    def forward(self, tokens, mem, mm=None):
        x = self.dr(self.emb(tokens) * math.sqrt(self.d) + self.pos(torch.arange(tokens.size(1), device=tokens.device)))
        for layer in self.layers:
            x = layer(x, mem, mm)
        return self.out(self.ln(x))


def lm_loss(logits, target):
    return F.cross_entropy(logits.reshape(-1, logits.size(-1)).float(), target.reshape(-1),
                           ignore_index=0, label_smoothing=CFG["LABEL_SMOOTH"])


@torch.no_grad()
def greedy_decode(step_fn, B, max_len, block_n=CFG["NO_REPEAT_N"]):
    """Greedy decoding with no-repeat n-gram blocking. step_fn(ys) -> logits of the next token, shape (B, V)."""
    ys = torch.full((B, 1), 1, dtype=torch.long, device=DEVICE)
    done = torch.zeros(B, dtype=torch.bool, device=DEVICE)
    for _ in range(max_len):
        lg = step_fn(ys).float()
        lg[:, 0] = lg[:, 1] = lg[:, 3] = -1e9                       # never emit <pad>/<bos>/<unk>
        if block_n and ys.size(1) >= block_n:
            seqs, dl = ys.tolist(), done.tolist()
            for i, sq in enumerate(seqs):
                if dl[i]:
                    continue
                pref = tuple(sq[-(block_n - 1):])
                for j in range(len(sq) - block_n + 1):
                    if tuple(sq[j:j + block_n - 1]) == pref:
                        lg[i, sq[j + block_n - 1]] = -1e9
        nxt = torch.where(done, torch.zeros_like(lg.argmax(-1)), lg.argmax(-1))
        ys = torch.cat([ys, nxt[:, None]], 1)
        done |= nxt == 2
        if done.all():
            break
    return ys[:, 1:]
