"""M1 (classic): ResNet-18 encoder + LSTM decoder with Bahdanau (additive) attention."""
import torch
import torch.nn as nn
import torchvision.models as tvm

from src.models.common import greedy_decode, lm_loss


class CNNLSTM(nn.Module):
    def __init__(self, V, pretrained=True, emb=256, hid=512, drop=0.3):
        super().__init__()
        r = tvm.resnet18(weights=tvm.ResNet18_Weights.IMAGENET1K_V1 if pretrained else None)
        self.enc = nn.Sequential(*list(r.children())[:-2])
        D = 512
        self.emb = nn.Embedding(V, emb, padding_idx=0)
        self.att_e, self.att_h, self.att_v = nn.Linear(D, hid), nn.Linear(hid, hid), nn.Linear(hid, 1)
        self.init_h, self.init_c = nn.Linear(D, hid), nn.Linear(D, hid)
        self.cell = nn.LSTMCell(emb + D, hid)
        self.drop, self.out = nn.Dropout(drop), nn.Linear(hid, V)

    def encoder_params(self):
        return self.enc.parameters()

    def encode(self, f):
        return self.enc(f).flatten(2).transpose(1, 2)               # (B, 49, 512)

    def init_state(self, feats):
        m = feats.mean(1)
        return torch.tanh(self.init_h(m)), torch.tanh(self.init_c(m))

    def step(self, tok, feats, st):
        h, c = st
        a = self.att_v(torch.tanh(self.att_e(feats) + self.att_h(h).unsqueeze(1))).squeeze(-1).softmax(-1)
        ctx = (a.unsqueeze(-1) * feats).sum(1)
        h, c = self.cell(torch.cat([self.emb(tok), ctx], -1), (h, c))
        return self.out(self.drop(h)), (h, c)

    def loss(self, b):
        feats = self.encode(b["f"]); st = self.init_state(feats); T = b["tokens"]; lgs = []
        for t in range(T.size(1) - 1):
            lg, st = self.step(T[:, t], feats, st)
            lgs.append(lg)
        l = lm_loss(torch.stack(lgs, 1), T[:, 1:])
        return l, {"lm": l.item()}

    @torch.no_grad()
    def generate(self, b, max_len):
        feats = self.encode(b["f"]); st = [self.init_state(feats)]

        def fn(ys):
            lg, st[0] = self.step(ys[:, -1], feats, st[0])
            return lg
        return greedy_decode(fn, feats.size(0), max_len)
