"""Shared evaluation for ALL models + report tables + error analysis.

Usage:
    python -m src.evaluate checkpoint --name M2 --ckpt checkpoints/M2__s0.pt --split test
    python -m src.evaluate tables          # tables 4,5,7, per-class F1, bootstrap CIs, hypothesis verdicts -> experiments/*.csv
    python -m src.evaluate errors          # table 6 + example figures for the best model (by validation score)
"""
import argparse
import json
import re

import numpy as np
import pandas as pd

from src.baselines import run_baselines
from src.config import CFG, CKPT, DEVICE, HW, NICE, RES, SPECS
from src.datasets.cxr import load_data, make_loader
from src.datasets.labeler import CORE_IDX, LABELS, label_vec
from src.metrics import boot_ci, compute_metrics, rouge_l
from src.models import build_model
from src.train import generate_all

COLS = ["bleu1", "bleu4", "rougeL", "ce_micro_f1", "ce_macro_f1", "composite"]
HEAD = {"bleu1": "BLEU-1", "bleu4": "BLEU-4", "rougeL": "ROUGE-L", "ce_micro_f1": "CE micro-F1", "ce_macro_f1": "CE macro-F1", "composite": "Composite"}


# --------------------------------------------------------------------------- evaluate one checkpoint
def evaluate_checkpoint(data, name, ckpt, split="test"):
    import torch
    model = build_model(SPECS[name], data.V).to(DEVICE)
    model.load_state_dict(torch.load(ckpt, map_location=DEVICE))
    hyps, dt = generate_all(model, make_loader(data.DS[split], False), data.tok)
    m = compute_metrics(data.REFS[split], hyps)
    print({k: round(v, 3) for k, v in m.items() if k != "per_class"}, f"| {1000*dt/len(hyps):.1f} ms/img")
    return m, hyps


# --------------------------------------------------------------------------- result loading helpers
def load_runs():
    return [json.load(open(p)) for p in sorted(RES.glob("run__*.json"))]


def runs_df(split="test", stages=("final", "study")):
    out = []
    for r in load_runs():
        if r["stage"] not in stages or f"metrics_{split}" not in r or r["epochs"] != CFG["EPOCHS"]:
            continue
        m = r[f"metrics_{split}"]
        row = dict(name=r["name"], seed=r["seed"], lr=r["lr"], stage=r["stage"], train_time=r["train_time_s"], params=r["params"],
                   peak_mem=r["peak_mem_mb"], infer_ms=r.get(f"infer_ms_{split}"), ckpt_mb=r.get("ckpt_mb"), epochs_run=r["epochs_run"])
        row.update({c: m[c] for c in ["bleu1", "bleu2", "bleu3", "bleu4", "rougeL", "ce_micro_f1", "ce_macro_f1", "composite", "avg_len"]})
        out.append(row)
    return pd.DataFrame(out)


def ms(d, c):
    return f"{d[c].mean():.3f} ± {d[c].std(ddof=1):.3f}" if len(d) > 1 else f"{d[c].mean():.3f}"


def result_table(names, df_):
    return pd.DataFrame([{"Model": n, "#seeds": int((df_.name == n).sum()), **{HEAD[c]: ms(df_[df_.name == n], c) for c in COLS}}
                         for n in names if (df_.name == n).any()])


def get_hyps(name, seed=0, split="test"):
    r = [x for x in load_runs() if x["name"] == name and x["seed"] == seed and x["epochs"] == CFG["EPOCHS"] and x["stage"] != "tune"][0]
    return json.load(open(r["preds"][split]))


# --------------------------------------------------------------------------- report tables
def make_tables(data):
    from scipy import stats
    TEST, VAL = runs_df("test"), runs_df("val")
    BASE = run_baselines(data); T = {}
    # Table 4: main results
    t4 = result_table(["M1", "M2", "M3"], TEST); t4["Model"] = t4.Model.map(NICE)
    base = pd.DataFrame([{"Model": k, "#seeds": "det.", **{HEAD[c]: f"{v['test'][c]:.3f}" for c in COLS}} for k, v in BASE.items()])
    T["table4_main_results"] = pd.concat([base, t4], ignore_index=True)
    T["val_results"] = result_table(["M1", "M2", "M3"], VAL)
    T["studies_results"] = result_table(["M1", "M1_scratch", "M2", "M2_scratch", "M2_noaug"], TEST)
    # per-class F1 (mean over seeds, test)
    finals = [r for r in load_runs() if r["stage"] == "final" and r["epochs"] == CFG["EPOCHS"] and "metrics_test" in r]
    pc = {k: pd.DataFrame([{l: r["metrics_test"]["per_class"][l]["f1"] for l in LABELS} for r in finals if r["name"] == k]).mean() for k in ["M1", "M2", "M3"]}
    kb = BASE["B1 kNN retrieval (PCA)"]["test"]["per_class"]
    pc["kNN"] = pd.Series({l: kb[l]["f1"] for l in LABELS})
    pct = pd.DataFrame(pc); pct.insert(0, "support", pd.Series({l: kb[l]["support"] for l in LABELS}))
    T["per_class_f1_test"] = pct
    # bootstrap CIs
    rows = []
    for nm, h in [("B1 kNN retrieval", BASE["B1 kNN retrieval (PCA)"]["hyps"])] + [(NICE[k], get_hyps(k)) for k in ["M1", "M2", "M3"]]:
        a, b = boot_ci(data.REFS["test"], h); mm = compute_metrics(data.REFS["test"], h)
        rows.append({"Model": nm, "BLEU-4": round(mm["bleu4"], 3), "BLEU-4 95% CI": a, "ROUGE-L": round(mm["rougeL"], 3), "ROUGE-L 95% CI": b})
    T["bootstrap_ci_test"] = pd.DataFrame(rows)
    # hypothesis verdicts (Welch t-test on seed-level scores; low power with 3 seeds)
    def compare(a, b, metric):
        A, B = TEST[TEST.name == a][metric].values, TEST[TEST.name == b][metric].values
        if len(A) < 2 or len(B) < 2:
            return None
        p = stats.ttest_ind(A, B, equal_var=False).pvalue
        return dict(pair=f"{a} vs {b}", metric=HEAD[metric], diff=A.mean() - B.mean(), p=1.0 if np.isnan(p) else p)
    HYP = [("H1 pretraining helps (CNN)", [("M1", "M1_scratch", "composite")]), ("H1 pretraining helps (ViT)", [("M2", "M2_scratch", "composite")]),
           ("H2 ViT-Transformer > CNN-LSTM", [("M2", "M1", "composite"), ("M2", "M1", "rougeL"), ("M2", "M1", "ce_macro_f1")]),
           ("H3 multi-view+tags improve CE-F1", [("M3", "M2", "ce_macro_f1"), ("M3", "M2", "ce_micro_f1")]),
           ("H3b ... more than they improve BLEU-4", [("M3", "M2", "bleu4")]), ("H4 augmentation helps", [("M2", "M2_noaug", "composite")])]
    vr = []
    for h, pairs in HYP:
        cs = [c for c in (compare(*p) for p in pairs) if c]
        if cs:
            v = "Supported" if all(c["diff"] > 0 and c["p"] < 0.10 for c in cs) else ("Weak evidence" if all(c["diff"] > 0 for c in cs) else "Rejected / not supported")
            vr.append({"Hypothesis": h, "Comparisons": "; ".join(f"{c['pair']} [{c['metric']}] d={c['diff']:+.3f} (p={c['p']:.2f})" for c in cs), "Verdict": v})
    T["hypothesis_verdicts"] = pd.DataFrame(vr)
    # Table 5: ablation
    def delta(full, variants, labels):
        out = []
        for v, lab in zip([full] + variants, ["Full model"] + labels):
            d = TEST[TEST.name == v]
            if d.empty:
                continue
            row = {"Component removed": lab, "BLEU-4": ms(d, "bleu4"), "ROUGE-L": ms(d, "rougeL"), "CE macro-F1": ms(d, "ce_macro_f1"), "Composite": ms(d, "composite")}
            for c, h in [("bleu4", "d BLEU-4"), ("rougeL", "d ROUGE-L"), ("ce_macro_f1", "d CE macro-F1")]:
                row[h] = f"{d[c].mean() - TEST[TEST.name == full][c].mean():+.3f}"
            out.append(row)
        return pd.DataFrame(out)
    T["table5_ablation"] = pd.concat([delta("M3", ["M3_nolat", "M3_notags"], ["- lateral view", "- tag module"]),
                                      delta("M2", ["M2_scratch", "M2_noaug"], ["- pretraining (M2)", "- augmentation (M2)"]).iloc[1:]], ignore_index=True)
    # Table 7: computational cost
    rows = []
    for k in ["M1", "M2", "M3"]:
        d = TEST[TEST.name == k]
        rows.append({"Model": NICE[k], "Parameters": f"{d.params.iloc[0]/1e6:.1f}M",
                     "Size (MB, ckpt)": f"{d.ckpt_mb.dropna().iloc[0]:.0f}" if d.ckpt_mb.notna().any() else "n/a",
                     "Train time / run (min)": f"{d.train_time.mean()/60:.1f} ± {d.train_time.std(ddof=1)/60:.1f}", "Epochs run": f"{d.epochs_run.mean():.1f}",
                     "Inference (ms/img)": f"{d.infer_ms.mean():.1f}", "Peak GPU mem (MB)": f"{d.peak_mem.mean():.0f}", "Hardware": HW})
    for k, v in BASE.items():
        rows.append({"Model": k, "Parameters": "-", "Size (MB, ckpt)": "-", "Train time / run (min)": f"{v['fit_s']/60:.2f}", "Epochs run": "-",
                     "Inference (ms/img)": f"{v['test']['infer_ms']:.2f}", "Peak GPU mem (MB)": "0", "Hardware": "CPU"})
    T["table7_cost"] = pd.DataFrame(rows)
    # best model by VALIDATION composite -> used by errors + demo
    best = VAL[VAL.name.isin(["M1", "M2", "M3"])].groupby("name").composite.mean().idxmax()
    json.dump({"best_model": best}, open(RES / "best_model.json", "w"))
    for n, t in T.items():
        t.to_csv(RES / f"{n}.csv", index=(n == "per_class_f1_test")); print(f"\n=== {n} ===\n{t.to_string()}")
    print("\nBest model by validation composite:", best)


# --------------------------------------------------------------------------- error analysis (Table 6)
CAUSE = {"Degenerate / repetitive text": "greedy decoding collapse, weak language modelling",
         "Wrong abnormality (missed + spurious)": "visual confusion between similar findings",
         "Missed abnormality (says normal)": "class imbalance: most reports are normal -> normal-template bias; subtle finding",
         "Partially missed abnormality": "rare / co-occurring findings under-represented in training",
         "Hallucinated abnormality": "language prior / dataset bias, over-prediction of common findings",
         "Clinically consistent, wording differs": "metric limitation: n-gram metrics penalise valid paraphrases",
         "Good match": "-"}


def error_analysis(data):
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    best = json.load(open(RES / "best_model.json"))["best_model"]
    hyps, refs = get_hyps(best), data.REFS["test"]; te = data.parts["test"]
    Yr = np.stack([label_vec(t) for t in refs]); Yh = np.stack([label_vec(t) for t in hyps]); rl = np.array([rouge_l(r, h) for r, h in zip(refs, hyps)])

    def categorize(i):
        toks = hyps[i].split(); r, h = Yr[i][CORE_IDX] > 0, Yh[i][CORE_IDX] > 0
        if len(toks) < 4 or (len(toks) > 8 and len(set(toks)) / len(toks) < 0.3):
            return "Degenerate / repetitive text"
        fn, fp = (r & ~h).any(), (h & ~r).any()
        if fn and fp:
            return "Wrong abnormality (missed + spurious)"
        if fn:
            return "Missed abnormality (says normal)" if not h.any() else "Partially missed abnormality"
        if fp:
            return "Hallucinated abnormality"
        return "Clinically consistent, wording differs" if rl[i] < 0.35 else "Good match"
    cat = np.array([categorize(i) for i in range(len(refs))]); rows = []
    for c in pd.Series(cat).value_counts().index:
        ix = np.where(cat == c)[0]; ex = ix[np.argmin(rl[ix])] if c != "Good match" else ix[np.argmax(rl[ix])]
        rows.append({"Error type": c, "Count": len(ix), "Share": f"{100*len(ix)/len(cat):.1f}%", "Example (test idx)": int(ex), "Likely cause": CAUSE[c]})
    t6 = pd.DataFrame(rows); t6.to_csv(RES / "table6_error_analysis.csv", index=False); print(t6.to_string())
    pd.DataFrame({"support": Yr.sum(0), "missed (FN)": ((Yr > 0) & (Yh == 0)).sum(0), "spurious (FP)": ((Yh > 0) & (Yr == 0)).sum(0)},
                 index=LABELS).astype(int).to_csv(RES / "error_per_class_fn_fp.csv")
    for c in ["Missed abnormality (says normal)", "Hallucinated abnormality", "Wrong abnormality (missed + spurious)", "Good match"]:
        ix = np.where(cat == c)[0]
        if not len(ix):
            continue
        i = int(ix[np.argmin(rl[ix])] if c != "Good match" else ix[np.argmax(rl[ix])])
        fig, ax = plt.subplots(1, 2, figsize=(13, 3.2), gridspec_kw={"width_ratios": [1, 3]})
        ax[0].imshow(data.IMGS[data.F2I[te.frontal[i]]], cmap="gray"); ax[0].axis("off"); ax[1].axis("off")
        ax[1].text(0, 1, f"{c} (idx {i}, ROUGE-L {rl[i]:.2f})\n\nREF : " + "\n       ".join(re.findall(r".{1,95}(?:\s|$)", refs[i])) +
                   "\n\nPRED: " + "\n         ".join(re.findall(r".{1,95}(?:\s|$)", hyps[i])), va="top", fontsize=8.5, family="monospace")
        fig.savefig(RES / f"error_example_{re.sub('[^a-z]+', '_', c.lower())}.png", dpi=120, bbox_inches="tight"); plt.close(fig)
    print("saved table6 + example figures to", RES)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("checkpoint"); c.add_argument("--name", required=True, choices=list(SPECS)); c.add_argument("--ckpt", required=True); c.add_argument("--split", default="test")
    sub.add_parser("tables"); sub.add_parser("errors")
    a = ap.parse_args(); d = load_data()
    if a.cmd == "checkpoint": evaluate_checkpoint(d, a.name, a.ckpt, a.split)
    elif a.cmd == "tables": make_tables(d)
    else: error_analysis(d)
