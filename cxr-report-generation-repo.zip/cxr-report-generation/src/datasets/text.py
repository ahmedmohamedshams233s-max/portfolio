"""Report-text cleaning and a word-level tokenizer (vocabulary is built from the TRAIN split only)."""
import collections
import re


def clean(t) -> str:
    if not isinstance(t, str):
        return ""
    t = t.lower().replace("xxxx", " ")
    t = re.sub(r"\d+(\.\d+)?", " ", t)
    out = []
    for w in re.findall(r"[a-z]+|\.", t):
        if w == "." and (not out or out[-1] == "."):
            continue                         # no leading / double periods
        out.append(w)
    return " ".join(out)


class Tokenizer:
    PAD, BOS, EOS, UNK = 0, 1, 2, 3

    def __init__(self, texts, min_freq):
        c = collections.Counter(w for t in texts for w in t.split())
        self.itos = ["<pad>", "<bos>", "<eos>", "<unk>"] + [w for w, k in c.most_common() if k >= min_freq]
        self.stoi = {w: i for i, w in enumerate(self.itos)}

    @classmethod
    def from_itos(cls, itos):
        o = cls.__new__(cls)
        o.itos, o.stoi = list(itos), {w: i for i, w in enumerate(itos)}
        return o

    def encode(self, t, max_len):
        return [1] + [self.stoi.get(w, 3) for w in t.split()][:max_len] + [2]

    def decode(self, ids):
        out = []
        for i in ids:
            i = int(i)
            if i in (0, 2):
                break
            if i > 3:
                out.append(self.itos[i])
        return " ".join(out)
