"""Dataset, image cache, collate/prep functions and the `load_data()` entry point."""
import json
from concurrent.futures import ThreadPoolExecutor
from types import SimpleNamespace

import numpy as np
import pandas as pd
import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from torchvision.transforms import v2

from src.config import CFG, DEVICE, PROC_DIR
from src.datasets.labeler import label_vec
from src.datasets.text import Tokenizer

S, MAX_LEN = CFG["IMG"], CFG["MAX_LEN"]
# no horizontal flip: left/right matters in radiology
AUG = v2.Compose([v2.RandomAffine(degrees=7, translate=(0.05, 0.05), scale=(0.9, 1.1)),
                  v2.ColorJitter(brightness=0.2, contrast=0.2)])
MEAN = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1).to(DEVICE)
STD = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1).to(DEVICE)


def load_image(path):
    return np.array(Image.open(path).convert("L").resize((S, S), Image.BILINEAR), dtype=np.uint8)


class CXRDataset(Dataset):
    def __init__(self, d, tok, imgs, f2i, augment=False):
        self.f, self.l = d.frontal.tolist(), d.lateral.tolist()
        self.ids = [tok.encode(t, MAX_LEN) for t in d.ref]
        self.y = np.stack(d.labels.tolist()).astype(np.float32)
        self.imgs, self.f2i, self.aug = imgs, f2i, augment

    def _img(self, name):
        x = self.imgs[self.f2i[name]].unsqueeze(0).expand(3, -1, -1).contiguous()
        return AUG(x) if self.aug else x

    def __len__(self):
        return len(self.f)

    def __getitem__(self, i):
        f = self._img(self.f[i]); has = isinstance(self.l[i], str)
        l = self._img(self.l[i]) if has else f.clone()
        return f, l, float(has), torch.tensor(self.ids[i]), torch.from_numpy(self.y[i]), i


def collate(b):
    f, l, h, t, y, i = zip(*b)
    T = torch.zeros(len(b), max(len(x) for x in t), dtype=torch.long)
    for k, x in enumerate(t):
        T[k, :len(x)] = x
    return torch.stack(f), torch.stack(l), torch.tensor(h), T, torch.stack(y), torch.tensor(i)


def make_loader(ds, shuffle, seed=0):
    g = torch.Generator(); g.manual_seed(seed)
    return DataLoader(ds, batch_size=CFG["BATCH"], shuffle=shuffle, collate_fn=collate, num_workers=2,
                      pin_memory=(DEVICE == "cuda"), generator=g)


def prep(batch):
    """Move a collated batch to the device and normalise the images (ImageNet statistics)."""
    f, l, h, T, y, i = batch
    norm = lambda x: (x.to(DEVICE, non_blocking=True).float() / 255 - MEAN) / STD
    return dict(f=norm(f), l=norm(l), has_l=h.to(DEVICE), tokens=T.to(DEVICE), labels=y.to(DEVICE), idx=i)


def load_data():
    """Read data/processed/studies.csv and build tokenizer, cached images and datasets."""
    meta = json.load(open(PROC_DIR / "meta.json"))
    img_dir = meta["img_dir"]
    df = pd.read_csv(PROC_DIR / "studies.csv")
    df["labels"] = [label_vec(t) for t in df.ref]
    parts = {s: df[df.split == s].reset_index(drop=True) for s in ["train", "val", "test"]}
    tok = Tokenizer(parts["train"].ref.tolist(), CFG["MIN_FREQ"])            # vocabulary from TRAIN only

    files = sorted(set(df.frontal) | set(df.lateral.dropna()))
    with ThreadPoolExecutor(8) as ex:
        arrs = list(ex.map(lambda f: load_image(f"{img_dir}/{f}"), files))
    imgs = torch.from_numpy(np.stack(arrs)); f2i = {f: i for i, f in enumerate(files)}

    ds = {"train": CXRDataset(parts["train"], tok, imgs, f2i, False), "train_aug": CXRDataset(parts["train"], tok, imgs, f2i, True),
          "val": CXRDataset(parts["val"], tok, imgs, f2i), "test": CXRDataset(parts["test"], tok, imgs, f2i)}
    refs = {s: parts[s].ref.tolist() for s in parts}
    print({k: len(v) for k, v in ds.items()}, "| vocab", len(tok.itos), "| images", tuple(imgs.shape))
    return SimpleNamespace(df=df, parts=parts, tok=tok, V=len(tok.itos), IMGS=imgs, F2I=f2i, DS=ds, REFS=refs)
