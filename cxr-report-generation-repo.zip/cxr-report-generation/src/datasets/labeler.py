"""Our own negation-aware, rule-based findings labeler (used for the auxiliary tag head and the clinical-efficacy metric)."""
import re

import numpy as np

PATTERNS = {
    "cardiomegaly":   r"cardiomegaly|enlarged heart|heart (size )?(is )?(mildly |moderately |markedly )?enlarged|cardiac silhouette (is )?(mildly |moderately |markedly )?enlarged",
    "effusion":       r"effusions?",
    "pneumothorax":   r"pneumothora(?:x|ces)",
    "pneumonia":      r"pneumonia|consolidation|infiltrates?",
    "atelectasis":    r"atelecta\w*",
    "edema":          r"edema",
    "opacity":        r"opacit(?:y|ies)|airspace disease|haziness",
    "nodule_mass":    r"nodul\w*|\bmass(?:es)?\b",
    "granuloma":      r"granulomas?|granulomatous|calcified",
    "emphysema_copd": r"emphysema|copd|hyperinflat\w*|hyperexpan\w*",
    "fracture":       r"fractures?",
    "spine_degen":    r"degenerative|spondylosis|scoliosis|osteophyt\w*",
    "device":         r"catheter|pacemaker|pacer|tube|stent|clips?|sternal wires?",
}
PAT = {k: re.compile(v) for k, v in PATTERNS.items()}
NEG_PRE = re.compile(r"\b(no|without|negative|clear|free|absent|resolved|normal|not|neither|nor)\b")
NEG_POST = re.compile(r"\b(not|absent|resolved|excluded)\b")
CORE = ["cardiomegaly", "effusion", "pneumothorax", "pneumonia", "atelectasis", "edema",
        "opacity", "nodule_mass", "emphysema_copd", "fracture"]
LABELS = list(PATTERNS) + ["no_finding"]
K = len(LABELS)
CORE_IDX = [LABELS.index(c) for c in CORE]


def label_vec(text: str) -> np.ndarray:
    """Multi-hot vector (K,) of findings mentioned (and not negated) in `text`."""
    v = np.zeros(K, np.float32)
    for sent in text.split("."):
        for j, pat in enumerate(PAT.values()):
            for m in pat.finditer(sent):
                if not (NEG_PRE.search(sent[:m.start()]) or NEG_POST.search(sent[m.end():m.end() + 30])):
                    v[j] = 1
                    break
    v[-1] = float(v[CORE_IDX].sum() == 0)
    return v
