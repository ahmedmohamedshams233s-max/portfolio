"""Classical-ML baselines: B0 generic report, B1 kNN retrieval on PCA of downsampled pixels.

Usage: python -m src.baselines
"""
import json
import time

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.decomposition import PCA
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

from src.config import RES
from src.datasets.cxr import load_data
from src.metrics import compute_metrics, rouge_l


def run_baselines(data):
    tr = data.parts["train"]

    def feats(d):
        x = data.IMGS[[data.F2I[f] for f in d.frontal]].float().unsqueeze(1) / 255
        return F.adaptive_avg_pool2d(x, 32).flatten(1).numpy()

    # B0: the single training report with the best mean ROUGE-L against a sample of training reports
    t0 = time.time(); r0 = np.random.RandomState(0)
    cands = r0.choice(len(tr), min(60, len(tr)), replace=False); refs_s = r0.choice(len(tr), min(150, len(tr)), replace=False)
    scores = [np.mean([rouge_l(tr.ref[j], tr.ref[c]) for j in refs_s]) for c in cands]
    generic = tr.ref[cands[int(np.argmax(scores))]]; t_b0 = time.time() - t0

    # B1: kNN retrieval
    t0 = time.time()
    sc = StandardScaler().fit(feats(tr)); pca = PCA(50, random_state=0).fit(sc.transform(feats(tr)))
    nn_ = NearestNeighbors(n_neighbors=1, metric="cosine").fit(pca.transform(sc.transform(feats(tr)))); t_b1 = time.time() - t0

    def knn(d):
        _, ix = nn_.kneighbors(pca.transform(sc.transform(feats(d))))
        return [tr.ref[i] for i in ix[:, 0]]

    out = {}
    for name, fn, fit in [("B0 Generic report", lambda d: [generic] * len(d), t_b0), ("B1 kNN retrieval (PCA)", knn, t_b1)]:
        out[name] = {"fit_s": fit}
        for sp in ["val", "test"]:
            t0 = time.time(); hyps = fn(data.parts[sp]); dt = time.time() - t0
            out[name][sp] = compute_metrics(data.REFS[sp], hyps); out[name][sp]["infer_ms"] = 1000 * dt / len(hyps)
            if sp == "test":
                out[name]["hyps"] = hyps
    json.dump(out, open(RES / "baselines.json", "w"))
    return out


if __name__ == "__main__":
    res = run_baselines(load_data())
    for k, v in res.items():
        print(k, {m: round(v["test"][m], 3) for m in ["bleu1", "bleu4", "rougeL", "ce_micro_f1", "ce_macro_f1", "composite"]})
