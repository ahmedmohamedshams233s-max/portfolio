# Chest X-ray Report Generation — Deep Learning (AI403) Final Project

**Team:** `<team name>` — `<members>`  |  **Idea chosen:** #8 Chest X-ray report generation (image → text)

## 1. Task and best result
Generate the *findings* section of a radiology report from chest X-ray image(s) (IU X-Ray / Open-i).
Three deep models are compared against classical baselines under an identical protocol:
**M1** ResNet-18 + attention-LSTM (classic) · **M2** ViT-S/16 + Transformer decoder (modern) · **M3** multi-view (frontal+lateral) tag-guided Transformer (advanced).

**Best result:** `<fill from experiments/table4_main_results.csv: model, BLEU-4, ROUGE-L, CE-F1 (mean ± SD over 3 seeds)>`

## 2. Environment setup
```bash
git clone <repo-url> && cd <repo>
pip install -r requirements.txt
```
Google Colab (T4 GPU) is recommended. `notebooks/CXR_Report_Generation_Final_Project.ipynb` runs the entire pipeline in one notebook; the scripts below do the same from the command line.

## 3. Dataset download and preprocessing
```bash
export KAGGLE_USERNAME=<kaggle username>      # never commit these
export KAGGLE_KEY=<kaggle API token>
python -m data.download                       # -> data/raw  (not tracked by git)
python -m data.preprocess                     # clean text, pair views, leakage-free split -> data/processed/studies.csv
```
Large files (raw data, checkpoints): shared drive link → `<link>`.  See `DATASET.md`-style details in the report (Table 1).

## 4. Training commands (one per model)
```bash
python -m src.train --name M1 --seed 0 --lr <best> --epochs 12 --splits val test --stage final --ckpt
python -m src.train --name M2 --seed 0 --lr <best> --epochs 12 --splits val test --stage final --ckpt
python -m src.train --name M3 --seed 0 --lr <best> --epochs 12 --splits val test --stage final --ckpt
python -m src.baselines                       # classical baselines
python -m src.run_all                         # FULL protocol: tuning -> 3 seeds x 3 models -> studies & ablations (resumable)
```
Add `CXR_SMOKE=1` in front of any command for a tiny pipeline test.  Configs per experiment: `configs/`.

## 5. Evaluation command
```bash
python -m src.evaluate checkpoint --name M3 --ckpt checkpoints/M3__s0.pt --split test   # same metrics for every model
python -m src.evaluate tables     # Tables 4,5,7, per-class F1, bootstrap CIs, hypothesis verdicts -> experiments/*.csv
python -m src.evaluate errors     # Table 6 + failure-case figures
```
## 6. Demo command
```bash
python -m demo.app --share        # Gradio; upload a chest X-ray, get report + findings (educational only)
```
## 7. Hardware and expected runtimes
`<GPU>`; full protocol ≈ 2–4 h on a Colab T4 (per-run times: `experiments/table7_cost.csv`).

## 8. Credits
IU X-Ray (Demner-Fushman et al., JAMIA 2016; Kaggle mirror `raddar/chest-xrays-indiana-university`) · torchvision ResNet-18 weights · timm ViT-S/16 weights · NLTK (BLEU) · scikit-learn · Gradio.
Written by us: multi-head attention, Transformer decoder, Bahdanau-attention LSTM, tag-token module, greedy decoder with n-gram blocking, ROUGE-L, rule-based findings labeler.
No external AI APIs are used for predictions.

> Educational prototype — not a medical device; no diagnosis or treatment advice.
