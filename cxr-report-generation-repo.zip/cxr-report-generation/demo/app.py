"""Gradio live demo.  Usage (repo root):  python -m demo.app [--model M3] [--share]

Needs checkpoints/<MODEL>__s0.pt and checkpoints/vocab.json (both written by `python -m src.train ... --ckpt`).
Educational prototype only - NOT for clinical use, no diagnosis or treatment advice.
"""
import argparse
import json

import gradio as gr
import numpy as np
import torch
from PIL import Image

from src.config import CFG, CKPT, DEVICE, NICE, RES, SPECS
from src.datasets.cxr import load_image, prep
from src.datasets.labeler import K, LABELS, label_vec
from src.datasets.text import Tokenizer
from src.models import build_model

MAX_LEN = CFG["MAX_LEN"]
AC = lambda: torch.autocast(device_type=DEVICE, dtype=torch.float16, enabled=(DEVICE == "cuda"))


def build(model_name):
    tok = Tokenizer.from_itos(json.load(open(CKPT / "vocab.json")))
    model = build_model(SPECS[model_name], len(tok.itos)).to(DEVICE)
    model.load_state_dict(torch.load(CKPT / f"{model_name}__s0.pt", map_location=DEVICE)); model.eval()
    return model, tok


def make_predict(model, tok):
    def to_tensor(im):
        x = np.array(im.convert("L").resize((CFG["IMG"], CFG["IMG"]), Image.BILINEAR), dtype=np.uint8)
        return torch.from_numpy(x).unsqueeze(0).expand(3, -1, -1).contiguous()

    @torch.no_grad()
    def predict(frontal, lateral=None):
        if frontal is None:
            return "Please upload a frontal chest X-ray.", {}, ""
        f = to_tensor(frontal); has = lateral is not None; l = to_tensor(lateral) if has else f.clone()
        b = prep((f[None], l[None], torch.tensor([float(has)]), torch.zeros(1, 2, dtype=torch.long), torch.zeros(1, K), torch.zeros(1, dtype=torch.long)))
        with AC():
            text = tok.decode(model.generate(b, MAX_LEN + 1)[0].cpu())
        tags = {n: 1.0 for n, x in zip(LABELS, label_vec(text)) if x} or {"no_finding": 1.0}
        if getattr(model, "use_tags", False):                                  # M3: probabilities from the tag head
            with AC():
                _, _, lg = model.memory(b)
            tags = {n: float(p) for n, p in zip(LABELS, torch.sigmoid(lg.float())[0].cpu())}
        found = [n for n, p in tags.items() if p >= 0.5 and n not in ("no_finding", "device")]
        summary = ("Possible findings (automated, unverified): " + ", ".join(n.replace("_", " ") for n in found)) if found else "No major abnormality detected by the model."
        summary += "\n\nAutomated output for education only. Not a diagnosis. Consult a physician/radiologist for interpretation and any treatment decisions."
        return text.replace(" .", ".").capitalize(), tags, summary
    return predict


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--model", default=None); ap.add_argument("--share", action="store_true")
    a = ap.parse_args()
    name = a.model or json.load(open(RES / "best_model.json"))["best_model"]
    model, tok = build(name)
    gr.Interface(fn=make_predict(model, tok),
                 inputs=[gr.Image(type="pil", label="Frontal chest X-ray"), gr.Image(type="pil", label="Lateral view (optional)")],
                 outputs=[gr.Textbox(label="Generated report", lines=5), gr.Label(num_top_classes=6, label="Findings"), gr.Textbox(label="Summary", lines=4)],
                 title=f"Chest X-ray Report Generation ({NICE[name]})",
                 description="Educational prototype (IU X-Ray). Not for clinical use.").launch(share=a.share)
