"""Download IU X-Ray from Kaggle straight into data/raw (never committed to git).

Usage (from the repo root):
    export KAGGLE_USERNAME=<your kaggle username>
    export KAGGLE_KEY=<your API token>
    python -m data.download

In Colab you can instead put KAGGLE_USERNAME / KAGGLE_KEY in Colab Secrets and copy them to os.environ first.
"""
import os
import subprocess
import sys

from src.config import DATA_DIR

SLUG = "raddar/chest-xrays-indiana-university"


def main():
    if any(DATA_DIR.rglob("indiana_reports.csv")):
        print("Dataset already present in", DATA_DIR)
        return
    if not os.environ.get("KAGGLE_KEY"):
        sys.exit("Set KAGGLE_USERNAME and KAGGLE_KEY (Kaggle -> Settings -> API -> Create New Token).")
    if os.environ["KAGGLE_KEY"].startswith("KGAT_"):
        os.environ["KAGGLE_API_TOKEN"] = os.environ["KAGGLE_KEY"]
    subprocess.check_call(["kaggle", "datasets", "download", "-d", SLUG, "-p", str(DATA_DIR), "--unzip"])
    print("Downloaded to", DATA_DIR)


if __name__ == "__main__":
    main()
