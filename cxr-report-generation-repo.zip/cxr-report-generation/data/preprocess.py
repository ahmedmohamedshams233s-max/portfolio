"""Clean the reports, pair frontal/lateral images and create the leakage-free train/val/test split.

Usage:  python -m data.preprocess            (full dataset)
        python -m data.preprocess --smoke    (500 studies, for a quick pipeline test)
Output: data/processed/studies.csv  (uid, frontal, lateral, ref, split)  +  data/processed/meta.json
"""
import argparse
import json

import numpy as np
import pandas as pd

from src.config import CFG, DATA_DIR, PROC_DIR
from src.datasets.text import clean


def find_file(name):
    hits = list(DATA_DIR.rglob(name))
    assert hits, f"{name} not found under {DATA_DIR} - run `python -m data.download` first"
    return hits[0]


def main(smoke=False):
    rep = pd.read_csv(find_file("indiana_reports.csv"))
    prj = pd.read_csv(find_file("indiana_projections.csv"))
    img_dir = [p for p in DATA_DIR.rglob("images_normalized") if p.is_dir()][0]

    fr = prj[prj.projection == "Frontal"].drop_duplicates("uid")[["uid", "filename"]].rename(columns={"filename": "frontal"})
    la = prj[prj.projection == "Lateral"].drop_duplicates("uid")[["uid", "filename"]].rename(columns={"filename": "lateral"})
    df = rep.merge(fr, on="uid", how="inner").merge(la, on="uid", how="left")

    f_clean, i_clean = df.findings.map(clean), df.impression.map(clean)
    df["text"] = [f if len(f.split()) >= 4 else i for f, i in zip(f_clean, i_clean)]   # findings, fallback impression
    df = df[df.text.str.split().str.len() >= 4]
    df = df[df.frontal.map(lambda f: (img_dir / f).exists())].reset_index(drop=True)
    df["ref"] = df.text.map(lambda t: " ".join(t.split()[:CFG["MAX_LEN"]]))
    if smoke:
        df = df.sample(500, random_state=0).reset_index(drop=True)

    # ---- split by study uid (both views of a study stay together) ----
    rng = np.random.RandomState(CFG["SPLIT_SEED"])
    uids = df.uid.unique().copy(); rng.shuffle(uids)
    n = len(uids); n_tr, n_va = int(.7 * n), int(.1 * n)
    split_of = {u: "train" for u in uids[:n_tr]}
    split_of.update({u: "val" for u in uids[n_tr:n_tr + n_va]})
    split_of.update({u: "test" for u in uids[n_tr + n_va:]})
    df["split"] = df.uid.map(split_of)

    # ---- leakage checks ----
    parts = {s: df[df.split == s] for s in ["train", "val", "test"]}
    files = {s: set(d.frontal) | set(d.lateral.dropna()) for s, d in parts.items()}
    for a, b in [("train", "val"), ("train", "test"), ("val", "test")]:
        assert not (set(parts[a].uid) & set(parts[b].uid)), f"uid overlap {a}/{b}"
        assert not (files[a] & files[b]), f"image overlap {a}/{b}"
    print({s: len(d) for s, d in parts.items()}, "-> no uid/image overlap between splits OK")

    df[["uid", "frontal", "lateral", "ref", "split"]].to_csv(PROC_DIR / "studies.csv", index=False)
    json.dump({"img_dir": str(img_dir), "n_studies": len(df)}, open(PROC_DIR / "meta.json", "w"))
    print("saved", PROC_DIR / "studies.csv")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--smoke", action="store_true")
    main(ap.parse_args().smoke)
